# css sprite

```

	css雪碧图简单制作工具
	
	可以通过图片，直接生成sprite文件，并且生成代码
	
	可以通过鼠标点击调整图片位置

	可以添加单张图片，以及删除单张图片

	可以保存为.sprite文件，以后好维护
	
```
		
# 编程不易大家支持下吧

![二维码](qrcode.png "nodeio")

# CSDN下载地址

http://download.csdn.net/detail/wx247919365/8741243

# V4.3最新版本介绍

http://www.cnblogs.com/wang4517/p/4529741.html
